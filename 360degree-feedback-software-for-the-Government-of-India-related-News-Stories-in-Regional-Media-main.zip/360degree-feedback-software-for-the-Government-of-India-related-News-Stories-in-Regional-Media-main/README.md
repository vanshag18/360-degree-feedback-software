# 360degree-feedback-software-for-the-Government-of-India-related-News-Stories-in-Regional-Media
Create AI feedback for PIB India: Monitors 200 sites, categorizes news by department and tone (pos/neutral/neg), alerts officers for negative news via SMS/Android, extracts e-paper clippings, scans YouTube for Govt. content, and categorizes it.
