from django.apps import AppConfig


class LegalComplianceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'legal_compliance'
