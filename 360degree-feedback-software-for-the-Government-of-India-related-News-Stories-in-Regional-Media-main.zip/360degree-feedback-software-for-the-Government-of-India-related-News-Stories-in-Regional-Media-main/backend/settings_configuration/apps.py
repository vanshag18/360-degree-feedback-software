from django.apps import AppConfig


class SettingsConfigurationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'settings_configuration'
