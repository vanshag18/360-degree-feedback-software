from django.apps import AppConfig


class DeploymentMonitoringConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'deployment_monitoring'
